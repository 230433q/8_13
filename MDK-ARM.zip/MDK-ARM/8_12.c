#include "8_12.h"

void BEEP_Setup(void){
  BEEP_ON;
  HAL_Delay(40);
  BEEP_OFF;
  HAL_Delay(60);
  BEEP_ON;
  HAL_Delay(80);
  BEEP_OFF;
  HAL_Delay(60);
  BEEP_ON;
  HAL_Delay(120);
  BEEP_OFF;
  HAL_Delay(60);
  BEEP_ON;
  HAL_Delay(160);
  BEEP_OFF;
}