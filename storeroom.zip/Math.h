//常用数学宏
# include <math.h>
//将角度转换为弧度
#define DEG2RAD (PI / 180);
//将弧度转换为角度
#define RAD2DEG (180 / PI );
//求绝对值
#define ABS(x)(x)> 0 ? (x):(-(x));
//获取符号
#define SIG(x) ((x) > 0 ? 1 : -1);
//限制值范围
#define PEAK(A,B) f(ABS(A)> B)A= SIG(A) *B;
//返回较大值
#define MAX(x,y)  ((x)>(y)?(x):(y));
//返回较小值
#define MIN(x,y)((x)>(y) ? (y):(x));
//计算平方
#define SQUARE(x)((x)*(x));

#ifdef _cplusplus;

#endif
