/* pack_bytes.h -----------------------------------------------------------*/
#ifndef PACK_BYTES_H_
#define PACK_BYTES_H_

#include <stdint.h>
#include <string.h>   /* for memcpy */

#ifdef __cplusplus
extern "C" {
#endif

/* ---------- 打包（主机字节序 → 字节流） ---------- */
static inline void pack_i16_to_bytes (int16_t  val, uint8_t *buf, uint8_t off);
static inline void pack_u16_to_bytes (uint16_t val, uint8_t *buf, uint8_t off);
static inline void pack_i32_to_bytes (int32_t  val, uint8_t *buf, uint8_t off);
static inline void pack_u32_to_bytes (uint32_t val, uint8_t *buf, uint8_t off);
static inline void pack_float_to_bytes(float     val, uint8_t *buf, uint8_t off);

/* ---------- 解析（字节流 → 主机字节序） ---------- */
static inline int16_t  unpack_bytes_to_i16 (const uint8_t *buf, uint8_t off);
static inline uint16_t unpack_bytes_to_u16 (const uint8_t *buf, uint8_t off);
static inline int32_t  unpack_bytes_to_i32 (const uint8_t *buf, uint8_t off);
static inline uint32_t unpack_bytes_to_u32 (const uint8_t *buf, uint8_t off);
static inline float    unpack_bytes_to_f32 (const uint8_t *buf, uint8_t off);

/* ---------- 字节序转换 ---------- */
int32_t swap_endian32(int32_t x);
int16_t swap_endian16(int16_t x);
void    swap_endian_in_place(uint8_t *buf, uint8_t elem_size, uint8_t off);

/* ---------- 内联实现 ---------- */
static inline void pack_i16_to_bytes(int16_t val, uint8_t *buf, uint8_t off)
{
    memcpy(buf + off, &val, sizeof(val));
}

static inline void pack_u16_to_bytes(uint16_t val, uint8_t *buf, uint8_t off)
{
    memcpy(buf + off, &val, sizeof(val));
}

static inline void pack_i32_to_bytes(int32_t val, uint8_t *buf, uint8_t off)
{
    memcpy(buf + off, &val, sizeof(val));
}

static inline void pack_u32_to_bytes(uint32_t val, uint8_t *buf, uint8_t off)
{
    memcpy(buf + off, &val, sizeof(val));
}

static inline void pack_float_to_bytes(float val, uint8_t *buf, uint8_t off)
{
    memcpy(buf + off, &val, sizeof(val));
}

static inline int16_t unpack_bytes_to_i16(const uint8_t *buf, uint8_t off)
{
    int16_t v;
    memcpy(&v, buf + off, sizeof(v));
    return v;
}

static inline uint16_t unpack_bytes_to_u16(const uint8_t *buf, uint8_t off)
{
    uint16_t v;
    memcpy(&v, buf + off, sizeof(v));
    return v;
}

static inline int32_t unpack_bytes_to_i32(const uint8_t *buf, uint8_t off)
{
    int32_t v;
    memcpy(&v, buf + off, sizeof(v));
    return v;
}

static inline uint32_t unpack_bytes_to_u32(const uint8_t *buf, uint8_t off)
{
    uint32_t v;
    memcpy(&v, buf + off, sizeof(v));
    return v;
}

static inline float unpack_bytes_to_f32(const uint8_t *buf, uint8_t off)
{
    float v;
    memcpy(&v, buf + off, sizeof(v));
    return v;
}

#ifdef __cplusplus
}
#endif
#endif /* PACK_BYTES_H_ */